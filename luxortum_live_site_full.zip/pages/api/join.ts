
import type { NextApiRequest, NextApiResponse } from 'next'
import sendgrid from '@sendgrid/mail'
sendgrid.setApiKey(process.env.SENDGRID_API_KEY || '')

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      await sendgrid.send({
        to: 'your@email.com',
        from: 'no-reply@luxortum.com',
        subject: 'Нова заявка Luxortum',
        text: JSON.stringify(req.body, null, 2),
      })
      res.status(200).json({ message: 'Заявка надіслана' })
    } catch (e) {
      res.status(500).json({ error: 'Не вдалося надіслати email' })
    }
  } else {
    res.status(405).end()
  }
}

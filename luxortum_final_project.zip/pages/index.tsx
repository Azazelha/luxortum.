import LuxortumGallery from '../components/LuxortumGallery'
import JoinForm from '../components/JoinForm'

export default function Home() {
  return (
    <main className="bg-black text-white min-h-screen font-mono px-6 py-10">
      <h1 className="text-4xl mb-10">Luxortum — Ритуальна Галерея</h1>
      <LuxortumGallery />
      <div className="mt-20">
        <JoinForm />
      </div>
    </main>
  )
}
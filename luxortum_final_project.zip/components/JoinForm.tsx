import React from 'react'

export default function JoinForm() {
  return (
    <form className="bg-gray-900 p-6 rounded space-y-4 max-w-xl mx-auto">
      <h2 className="text-xl font-semibold">Приєднатися до Luxortum</h2>
      <input type="text" placeholder="Ваше ім’я" className="w-full p-2 rounded bg-black text-white border" />
      <input type="email" placeholder="Email" className="w-full p-2 rounded bg-black text-white border" />
      <textarea placeholder="Повідомлення або інтенція..." className="w-full p-2 rounded bg-black text-white border" />
      <button type="submit" className="bg-indigo-600 px-4 py-2 rounded hover:bg-indigo-800">Відправити</button>
    </form>
  )
}
import React from 'react'
import galleryData from '../data/luxortum_gallery_data.json'

export default function LuxortumGallery() {
  return (
    <div className="space-y-16">
      <div className="grid sm:grid-cols-2 gap-8">
        {galleryData.visuals.map((item, i) => (
          <div key={i} className="bg-gray-900 p-4 rounded">
            <img src={item.imageUrl} alt={item.title} className="rounded mb-2" />
            <h3 className="text-lg font-bold">{item.title}</h3>
            <p className="text-sm">{item.description}</p>
          </div>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 gap-8">
        {galleryData.audio.map((item, i) => (
          <div key={i} className="bg-gray-800 p-4 rounded">
            <img src={item.coverImage} alt={item.title} className="rounded mb-2" />
            <h3 className="text-lg font-semibold">{item.title}</h3>
            <audio controls src={item.audioUrl} className="w-full mt-2" />
            <p className="text-xs text-gray-400 mt-2">Duration: {item.duration} | Theme: {item.theme}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
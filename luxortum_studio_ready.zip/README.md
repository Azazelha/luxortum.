# Luxortum — Sanity Studio Ready

## Що в цьому пакеті:
- `galleryItem.js` — схема образів
- `ritualAudio.js` — схема ритуального аудіо
- `luxortum_gallery_import.ndjson` — дані для імпорту

## Як використовувати:

1. Додай `galleryItem.js` та `ritualAudio.js` в `/schemas` вашого Sanity Studio
2. У `schema.js` імпортуй їх:
   ```js
   import galleryItem from './galleryItem'
   import ritualAudio from './ritualAudio'

   export default createSchema({
     name: 'default',
     types: schemaTypes.concat([galleryItem, ritualAudio])
   })
   ```
3. Запусти:
   ```
   sanity start
   ```
4. Імпортуй дані:
   ```
   sanity dataset import luxortum_gallery_import.ndjson production
   ```
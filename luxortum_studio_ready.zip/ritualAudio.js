export default {
  name: 'ritualAudio',
  title: 'Ritual Audio',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'audioUrl', title: 'Audio URL', type: 'url' },
    {
      name: 'coverImage', title: 'Cover Image', type: 'image',
      options: { hotspot: true }
    },
    { name: 'duration', title: 'Duration', type: 'string' },
    { name: 'theme', title: 'Theme', type: 'string' }
  ]
}